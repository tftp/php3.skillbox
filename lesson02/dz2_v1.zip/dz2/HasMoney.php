<?php

interface HasMoney
{
    public function getMoney(): int;
}
